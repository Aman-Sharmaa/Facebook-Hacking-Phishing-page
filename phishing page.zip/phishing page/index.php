<!DOCTYPE html>
<html>
<head>
	<title>Love Spectrometer</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://fonts.googleapis.com/css2?family=Asap&family=Dancing+Script:wght@700&display=swap" rel="stylesheet"> 
</head>
<body>
 
  <div class="navbar">
  	 <div class="logo"><p>Love <img src="heart.gif" > Spectrometer </p></div>
  	 <div class="right-logo">
  	 	<a href="signup.php">Sign Up</a>
  	 </div>

  </div>
<a href="signup.php">
  <div class="partner">
  	<div class="image"><img src="know.jpg"></div>
    <div class="name"><p>Know Your Partner</p></div>
  </div>
</a>

<a href="signup.php">
  <div class="partner">
  	<div class="image"><img src="meter.jpg"></div>
    <div class="name"><p>Love Meter</p></div>
  </div></a>

<a href="signup.php">
  <div class="partner">
  	<div class="image"><img src="quiz.png"></div>
    <div class="name"><p>Love Quiz</p></div>
  </div></a>

<a href="signup.php">
  <div class="partner">
  	<div class="image"><img src="quote.jpeg"></div>
    <div class="name"><p>Love Quotes</p></div>
  </div></a>


<a href="signup.php">
  <div class="partner">
  	<div class="image"><img src="know.jpg"></div>
    <div class="name"><p>Know Your Partner</p></div>
  </div></a>


<a href="signup.php">
  <div class="partner">
  	<div class="image"><img src="meter.jpg"></div>
    <div class="name"><p>Love Meter</p></div>
  </div></a>


<a href="signup.php">
  <div class="partner">
  	<div class="image"><img src="quiz.png"></div>
    <div class="name"><p>Love Quiz</p></div>
  </div></a>


<a href="signup.php">
  <div class="partner">
  	<div class="image"><img src="quote.jpeg"></div>
    <div class="name"><p>Love Quotes</p></div>
  </div></a>



  <div class="footer-div">
    <p>design by love spectrometer</p>
    <p>copyright 2020 - 2025</p>
    <p><a href="mailto:lovespectrometer@gmail.com">Mail</a></p>
    <p>Contact us </p>

  </div>

</body>
</html>